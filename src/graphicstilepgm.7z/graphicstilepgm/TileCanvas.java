/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphicstilepgm;

import java.awt.Graphics;
import java.awt.Image;
import java.awt.Toolkit;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import javax.swing.JPanel;

/**
 *
 * @author nitin
 */
////this class works with the center grid and accesses the 2 arrays in TileDesignerLayout as well
class TileCanvas extends JPanel implements MouseListener
{
public int selectedTile = -1; //this is set in other class with button clicks
static final int squareSide = 25; 
int GridRow =5,GridCol=5;	
int gridWidth, gridHeight, startX, startY;
int gridRows = 5, gridCols = 5;

//Image[][] gif2dArray = new Image[gridRows][gridCols];// drawn on grid when we paint
Image[][] gif2dArray = new Image[gridRows][gridCols];// drawn on grid when we paint

           //this gets the names of images out off array made above and builds an
            //  array of type image
public void LoadImageArray(){
    
                for(int i=0;i<TileDesignerLayout.imageA.length;i++)
            {
              TileDesignerLayout.imageA[i]=(Image) Toolkit.getDefaultToolkit().getImage(TileDesignerLayout.imageStringNameA[i]);
            }//for
}//LoadImageArray	

public void ResetGridTile(){
    for(int row = 0; row < 5; row++)
 {
     for(int col = 0; col < 5; col++)
     {
        gif2dArray[row][col]=null;
     }//col for
 }
    this.repaint();  //draw empty grid
}  //use in/out loop 
  
	
public void CreateMouseListener()//Add mouselistener to Center panel..need mouse methods at bottom
{ 
    addMouseListener(this);
}//CreateMouseListener

//user has clicked a tile on panel, now has clicked in the 5 x 5 grid
//public void mouseClicked(MouseEvent arg0) 
@Override
public void mouseClicked(MouseEvent e) 
{
 //here we get  a position of the click of mouse –x,y

    int x = e.getX();
    int y = e.getY();
                  //if it was a valid click in grid
 if(x >= startX && x <= startX+gridWidth && y >= startY && y <= startY+gridWidth)
 {
   int xIndex = (x-startX)/squareSide; //will be an integer of square clicked
   int yIndex = (y-startY)/squareSide; //wil be an integer of squear clicked
       
   //            col      row     
   gif2dArray[xIndex][yIndex] = TileDesignerLayout.imageA[selectedTile];
   //System.out.println("user clicked" + xIndex +"row"+ yIndex +"col");
    this.repaint();  //show new grid
 }//if
}//mouse clicked

@Override
 public void mouseEntered(MouseEvent e) { }
 @Override
 public void mouseExited(MouseEvent e) { }
 @Override
 public void mousePressed(MouseEvent e) { }      
 @Override
 public void mouseReleased(MouseEvent e) { }


public void paintComponent(Graphics g)	//Implementing paint component
{ 
  super.paintComponent(g);

//  gridWidth = gridCols*squareSide;
//  gridHeight = gridRows*squareSide;
  gridWidth = GridCol*squareSide;
  gridHeight = GridRow*squareSide;
  int panelWidth = getWidth();
  int panelHeight = getHeight();
  startX = (panelWidth-gridWidth)/2;//get starting point to draw grid based 
  startY = (panelHeight-gridHeight)/2;

  //System.out.println(panelWidth);
  //System.out.println(panelHeight);
 //Drawing empty grid of 5*5 with an inner outer loop
 
 for(int row = 0; row < 5; row++)
 {
     for(int col = 0; col < 5; col++)
     {
        g.drawRect(startX+(squareSide*row), startY+(squareSide*col), squareSide, squareSide);
     }//col for
 }//row for
 
 
// //copy gif image array over to the drawing grid with inner outer loop
for(int row = 0; row < 5; row++){
    for(int col = 0; col < 5; col++){  
 g.drawImage(gif2dArray[row][col], startX+(squareSide*row), startY+(squareSide*col), this);
  
    }//col for
}//row for
  //g.drawImage(gif2dArray[GridRow][GridCol], startX+(squareSide*GridRow), startY+(squareSide*GridCol), this);
    }//paintComponent

}//tileCanvas

