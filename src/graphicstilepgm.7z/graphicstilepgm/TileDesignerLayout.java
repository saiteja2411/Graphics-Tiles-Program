/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphicstilepgm;

import java.awt.BorderLayout;
import java.awt.Image;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JToolBar;

/**
 *
 * @author nitin
 */
class TileDesignerLayout extends JPanel implements ActionListener
{
public static String[] imageStringNameA ={"pat1.gif","pat2.gif","pat3.gif","pat4.gif","pat5.gif"};	//holds names of patches
public static Image[] imageA = new Image[5];	 //image array to hold 5 images that are loaded

JButton patch1btn,
        patch2btn,
        patch3btn,
        patch4btn,
        patch5btn,
        resetBtn;
//all buttons….

JPanel bottomPanel = new JPanel();
//

public TileDesignerLayout()
{
     setLayout(new BorderLayout());

     final TileCanvas centerTileCanvas1 = new TileCanvas(); //call class to make    center grid
 
     //add(centerPanel1ptr, BorderLayout.CENTER); //Adding centerPanel to outerFrame.
add(centerTileCanvas1, BorderLayout.CENTER); //Adding centerPanel to outerFrame.
//centerTileCanvas1.LoadImageArray();
centerTileCanvas1.ResetGridTile(); //call methods in other class to set stuff up		
//								
       centerTileCanvas1.CreateMouseListener();								
//          //(also add panel with reset button to SOUTH)

        JToolBar tileToolBar = new JToolBar();	//create a tool bar

//           imageStringNameA[0] = "C:\\Users\\nitin\\Documents\\NetBeansProjects\\GraphicsTilePGM\\src\\graphicstilepgm\\pat1.gif";
//           imageStringNameA[1] = "C:\\Users\\nitin\\Documents\\NetBeansProjects\\GraphicsTilePGM\\src\\graphicstilepgm\\pat2.gif";
//           imageStringNameA[2] = "C:\\Users\\nitin\\Documents\\NetBeansProjects\\GraphicsTilePGM\\src\\graphicstilepgm\\pat3.gif";
//           imageStringNameA[3] = "C:\\Users\\nitin\\Documents\\NetBeansProjects\\GraphicsTilePGM\\src\\graphicstilepgm\\pat4.gif";
//           imageStringNameA[4] = "C:\\Users\\nitin\\Documents\\NetBeansProjects\\GraphicsTilePGM\\src\\graphicstilepgm\\pat5.gif";

 centerTileCanvas1.LoadImageArray();           
  patch1btn = new JButton(new ImageIcon(imageA[0])); 
  patch2btn = new JButton(new ImageIcon(imageA[1])); 
  patch3btn = new JButton(new ImageIcon(imageA[2])); 
  patch4btn = new JButton(new ImageIcon(imageA[3])); 
  patch5btn = new JButton(new ImageIcon(imageA[4])); 
  resetBtn = new JButton("Reset");
  bottomPanel.add(resetBtn);
         tileToolBar.add(patch1btn); //add 1 button to toolbar
         tileToolBar.add(patch2btn);
         tileToolBar.add(patch3btn);
         tileToolBar.add(patch4btn);
         tileToolBar.add(patch5btn);
         add(tileToolBar,BorderLayout.NORTH);
         add(bottomPanel,BorderLayout.SOUTH);
         
         resetBtn.addActionListener(new ActionListener() {
         @Override
         public void actionPerformed(java.awt.event.ActionEvent ae) {
             centerTileCanvas1.ResetGridTile();
         }
     });
	
        patch1btn.addActionListener(new ActionListener() 							
       { 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) 
        {
          centerTileCanvas1.selectedTile = 0;
        //System.out.println("Clicked first tile");
        }
       });  
        
        patch2btn.addActionListener(new ActionListener() 							
       { 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) 
        {
          centerTileCanvas1.selectedTile = 1;
        //System.out.println("Clicked second tile");
        }
       });  
                
        patch3btn.addActionListener(new ActionListener() 							
       { 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) 
        {
          centerTileCanvas1.selectedTile = 2;}
       });  
                        
        patch4btn.addActionListener(new ActionListener() 							
       { 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) 
        {
          centerTileCanvas1.selectedTile = 3;}
       });  
                                
        patch5btn.addActionListener(new ActionListener() 							
       { 
           @Override
           public void actionPerformed(java.awt.event.ActionEvent e) 
        {
          centerTileCanvas1.selectedTile = 4;}
       });  

      //another way of setting up buttons to be listeners in constructor
//f                                                      set tile variable to 0…			
}  //END CONSTRUCTOR


         @Override
public void actionPerformed(java.awt.event.ActionEvent e){}
//
}//TileLayoutDesigner Class
