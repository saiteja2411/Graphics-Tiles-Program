/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package graphicstilepgm;


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import static javafx.beans.binding.Bindings.add;
import javafx.event.ActionEvent;
import javax.swing.JButton;
import java.awt.Toolkit;
import java.awt.event.ActionListener;
import javafx.event.ActionEvent;
//import java.awt.event.*;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import static graphicstilepgm.TileDesignerLayout.imageA;

/**
 *
 * @author nitin
 */
//on start up create on object of the tiledesignerlayout

public class GraphicsTilePGM extends JFrame{
    
    public static void main(String args[]){
     createAndShowGUI();     
    }//main
    
  public static void createAndShowGUI() {
 GraphicsTilePGM frame = new GraphicsTilePGM();
 frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
 frame.setSize(1200, 800);
 frame.setVisible(true);    
}//createAndShow
  
  
public GraphicsTilePGM() {
  super();
 // call a class to design the GUI 
  setSize(800, 600);
  TileDesignerLayout tiledesign = new TileDesignerLayout();
  setLayout(new BorderLayout());
  add(tiledesign,BorderLayout.CENTER);
 

}//GraphicsTilesPgmConstructor

}//GraphicsTilePGM


   
